# SalaryManagementSystem
 
It's a PL/SQL project. I created this project with distributed database.
Salary Management has 3 users
1. Admin/HR
2. Accountant
3. Employee


Each has several functionality

More details on: 

https://nowshad7.blogspot.com/p/salary-management-system.html
